"""
tf_aggregator.launch.py
Bridges namespaced transforms to the global tree for multi-robot RViz.

Author: H.A. Sharif
Year: 2026
"""

import os
import yaml
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    chroma_sim_dir = get_package_share_directory('chroma_simulation')
    swarm_config_path = os.path.join(chroma_sim_dir, 'config', 'swarm_config.yaml')

    with open(swarm_config_path, 'r') as f:
        swarm_data = yaml.safe_load(f)

    relay_nodes = []
    for robot_id in swarm_data.get('swarm', {}).keys():
        relay_nodes.append(Node(
            package='topic_tools',
            executable='relay',
            name=f'tf_relay_{robot_id}',
            arguments=[f'/{robot_id}/tf', '/tf'],
            output='screen'
        ))

        relay_nodes.append(Node(
            package='topic_tools',
            executable='relay',
            name=f'tf_static_relay_{robot_id}',
            arguments=[f'/{robot_id}/tf_static', '/tf_static'],
            output='screen'
        ))

    return LaunchDescription(relay_nodes)